(function () {
  if (window.__SIGHTLINE_LOADED__) return;
  window.__SIGHTLINE_LOADED__ = true;

  // ─── Constants ───────────────────────────────────────────────────────────────

  const STORAGE_KEY = 'sightline_guides';
  const TRAY_KEY    = 'sightline_tray_open';

  const BLUE   = '#1D4ED8';
  const AMBER  = '#F59E0B';
  const MINT   = '#10B981';

  // ─── State ───────────────────────────────────────────────────────────────────

  let guides        = [];
  let nextId        = 1;
  let trayVisible   = false;
  let guidesVisible = true;
  let inspectorActive = false;
  let inspectorRAF    = null;
  let lastTarget      = null;

  // DOM refs
  let overlayEl    = null;   // guide lines
  let inspectorEl  = null;   // box model coloured rects
  let inspectorTip = null;   // spacing tooltip near cursor
  let cascadePanel = null;   // css rules side panel
  let trayEl       = null;
  let btnInspect   = null;

  // ─── Bootstrap ───────────────────────────────────────────────────────────────
  // Read BOTH guides and tray state together so tray shows on page load
  // if it was already open on another tab.

  chrome.storage.local.get([STORAGE_KEY, TRAY_KEY], (data) => {
    guides = data[STORAGE_KEY] || [];
    if (guides.length) nextId = Math.max(...guides.map(g => g.id)) + 1;
    buildDOM();
    renderAll();

    // Restore tray if it was open on another tab
    if (data[TRAY_KEY]) {
      trayVisible = true;
      trayEl.style.display = 'flex';
    }
  });

  // ─── DOM construction ────────────────────────────────────────────────────────

  function buildDOM() {
    buildOverlay();
    buildInspectorLayer();
    buildCascadePanel();
    buildTray();
    attachListeners();
  }

  function buildOverlay() {
    overlayEl = div({ position:'fixed', inset:'0', width:'100vw', height:'100vh',
      pointerEvents:'none', zIndex:'2147483646', overflow:'hidden' }, 'overlay');
    document.documentElement.appendChild(overlayEl);
  }

  function buildInspectorLayer() {
    inspectorEl = div({ position:'fixed', inset:'0', width:'100vw', height:'100vh',
      pointerEvents:'none', zIndex:'2147483644', overflow:'visible' }, 'inspector');

    // Spacing tooltip — follows cursor
    inspectorTip = div({
      position:'fixed', display:'none', zIndex:'2147483647', pointerEvents:'none',
      background:'rgba(13,13,18,0.97)', border:'1px solid rgba(255,255,255,0.10)',
      borderRadius:'10px', padding:'10px 13px',
      fontFamily:'ui-monospace,"Cascadia Code","Fira Code",monospace',
      fontSize:'11px', lineHeight:'1.75', color:'#e2e8f0',
      boxShadow:'0 12px 40px rgba(0,0,0,0.6)',
      minWidth:'200px', maxWidth:'290px', whiteSpace:'nowrap',
    }, 'tip');
    inspectorEl.appendChild(inspectorTip);
    document.documentElement.appendChild(inspectorEl);
  }

  // Cascade panel — docked right, updates as you hover
  function buildCascadePanel() {
    cascadePanel = div({
      position:'fixed', top:'50%', right:'14px', transform:'translateY(-50%)',
      width:'300px', maxHeight:'72vh', display:'none', flexDirection:'column',
      background:'rgba(13,13,18,0.97)', border:'1px solid rgba(255,255,255,0.10)',
      borderRadius:'12px', zIndex:'2147483647', pointerEvents:'auto',
      fontFamily:'ui-monospace,"Cascadia Code","Fira Code",monospace',
      fontSize:'11px', color:'#e2e8f0', overflow:'hidden',
      boxShadow:'0 16px 48px rgba(0,0,0,0.65)',
    }, 'cascade');

    // Header
    const hdr = mk('div', { padding:'10px 14px 8px',
      borderBottom:'1px solid rgba(255,255,255,0.08)',
      display:'flex', alignItems:'center', justifyContent:'space-between', flexShrink:'0' });

    const titleRow = mk('div', { display:'flex', alignItems:'center', gap:'8px' });

    const dot = mk('div', { width:'6px', height:'6px', borderRadius:'50%',
      background:MINT, flexShrink:'0' });

    const titleTxt = mk('span', { fontSize:'10px', fontWeight:'500',
      color:'rgba(255,255,255,0.5)', letterSpacing:'.07em' });
    titleTxt.textContent = 'CSS CASCADE';
    titleRow.append(dot, titleTxt);

    const elTag = mk('div', { fontSize:'11px', color:'rgba(255,255,255,0.8)',
      fontWeight:'500', maxWidth:'150px', overflow:'hidden',
      textOverflow:'ellipsis', whiteSpace:'nowrap' });
    elTag.id = '__sl_cascade_tag__';
    elTag.textContent = '—';

    hdr.append(titleRow, elTag);
    cascadePanel.appendChild(hdr);

    // Hint line
    const hint = mk('div', { padding:'6px 14px 5px',
      borderBottom:'1px solid rgba(255,255,255,0.05)',
      color:'rgba(255,255,255,0.25)', fontSize:'10px', flexShrink:'0' });
    hint.id = '__sl_cascade_hint__';
    hint.textContent = 'Hover any element';
    cascadePanel.appendChild(hint);

    // Rule list (scrollable)
    const list = mk('div', { overflowY:'auto', flex:'1', padding:'0' });
    list.id = '__sl_cascade_list__';
    cascadePanel.appendChild(list);

    document.documentElement.appendChild(cascadePanel);
  }

  function buildTray() {
    trayEl = div({
      position:'fixed', bottom:'20px', left:'50%', transform:'translateX(-50%)',
      display:'none', alignItems:'center', gap:'5px',
      background:'rgba(13,13,18,0.96)', backdropFilter:'blur(12px)',
      border:'1px solid rgba(255,255,255,0.11)', borderRadius:'14px',
      padding:'8px 12px', zIndex:'2147483647', userSelect:'none',
      boxShadow:'0 8px 36px rgba(0,0,0,0.5)',
      fontFamily:'-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif',
    }, 'tray');

    const handle = mk('div', {
      color:'rgba(255,255,255,0.28)', fontSize:'14px',
      cursor:'grab', padding:'0 3px', lineHeight:'1',
    });
    handle.textContent = '⠿';
    handle.setAttribute('data-sightline-drag', '');

    const btnH   = mkBtn('─ H',      BLUE,  () => addGuide('h'));
    const btnV   = mkBtn('│ V',      AMBER, () => addGuide('v'));
    btnInspect   = mkBtn('◈ Inspect', MINT, toggleInspector);
    const btnEye = mkBtn('👁',       null,  toggleVisibility); btnEye.setAttribute('data-eye','');
    const btnClr = mkBtn('✕',        '#EF4444', clearAll);

    trayEl.append(handle, btnH, btnV, mkSep(), btnInspect, mkSep(), btnEye, btnClr);
    document.documentElement.appendChild(trayEl);
    makeTrayDraggable(handle);
  }

  // ─── Inspector — merged box model + cascade ───────────────────────────────────
  // Single mode. Activating it shows:
  //   • Coloured box-model overlays on every element you hover
  //   • Spacing tooltip near cursor
  //   • Cascade panel on the right updates with matched CSS rules

  function toggleInspector() {
    inspectorActive = !inspectorActive;

    if (inspectorActive) {
      document.body.style.cursor = 'crosshair';
      cascadePanel.style.display = 'flex';
      lastTarget = null;
    } else {
      document.body.style.cursor = '';
      cascadePanel.style.display = 'none';
      clearBoxes();
    }

    const on = inspectorActive;
    css(btnInspect, {
      background: on ? MINT+'30' : MINT+'18',
      border:     `1px solid ${on ? MINT+'80' : MINT+'40'}`,
      color:       on ? MINT : MINT+'bb',
    });
    btnInspect.textContent = on ? '◈ on' : '◈ Inspect';
  }

  function clearBoxes() {
    inspectorEl.querySelectorAll('[data-ibox]').forEach(n => n.remove());
    inspectorTip.style.display = 'none';
    lastTarget = null;
  }

  // ─── Hover handler ───────────────────────────────────────────────────────────

  function attachListeners() {
    window.addEventListener('mousemove', (e) => {
      if (!inspectorActive) return;
      if (inspectorRAF) cancelAnimationFrame(inspectorRAF);
      inspectorRAF = requestAnimationFrame(() => onHover(e));
    }, { passive: true });

    // Click while inspecting → exit mode
    window.addEventListener('click', (e) => {
      if (inspectorActive && !e.target.closest('[data-sightline]'))
        toggleInspector();
    }, true);

    // Keyboard: I to toggle inspector
    window.addEventListener('keydown', (e) => {
      if (['INPUT','TEXTAREA'].includes(document.activeElement?.tagName)) return;
      if (!trayVisible) return;
      if (e.key === 'i' || e.key === 'I') toggleInspector();
    });
  }

  function onHover(e) {
    const target = resolveTarget(e.clientX, e.clientY);
    if (!target) return;

    // Always update tooltip position
    if (target === lastTarget) {
      positionTip(e.clientX, e.clientY);
      return;
    }

    lastTarget = target;
    paintBoxModel(target);         // coloured overlays + tooltip content
    paintCascade(target);          // cascade panel rules
    positionTip(e.clientX, e.clientY);
  }

  function resolveTarget(x, y) {
    for (const node of document.elementsFromPoint(x, y)) {
      if (node.closest('[data-sightline]')) continue;
      if (node === document.documentElement || node === document.body) continue;
      return node;
    }
    return null;
  }

  // ─── Box model overlays ──────────────────────────────────────────────────────

  function paintBoxModel(target) {
    inspectorEl.querySelectorAll('[data-ibox]').forEach(n => n.remove());

    const rect   = target.getBoundingClientRect();
    const cs     = getComputedStyle(target);
    const rootFz = parseFloat(getComputedStyle(document.documentElement).fontSize) || 16;

    const m = sides(cs, 'margin');
    const b = sides(cs, 'border', 'Width');
    const p = sides(cs, 'padding');

    const marginRect  = expand(rect, m.top, m.right, m.bottom, m.left);
    const borderRect  = { top:rect.top, left:rect.left, width:rect.width, height:rect.height };
    const paddingRect = shrink(borderRect, b.top, b.right, b.bottom, b.left);
    const contentRect = shrink(paddingRect, p.top, p.right, p.bottom, p.left);

    // Stack layers bottom → top
    drawRect(marginRect,  'rgba(246,173,85,0.22)',  '1.5px dashed rgba(246,173,85,0.72)');
    drawRect(borderRect,  'rgba(213,120,39,0.28)',  'none');
    drawRect(paddingRect, 'rgba(104,211,145,0.36)', 'none');
    drawRect(contentRect, 'rgba(99,179,237,0.44)',  'none');
    drawRect(borderRect,  'transparent',             '1.5px solid rgba(99,179,237,0.92)');

    // Side labels
    const cx = rect.left + rect.width/2, cy = rect.top + rect.height/2;
    if (m.top)    sideLabel(cx, rect.top    - m.top/2,    ri(m.top),    '#C05621');
    if (m.bottom) sideLabel(cx, rect.bottom + m.bottom/2, ri(m.bottom), '#C05621');
    if (m.left)   sideLabel(rect.left  - m.left/2,  cy,  ri(m.left),   '#C05621');
    if (m.right)  sideLabel(rect.right + m.right/2, cy,  ri(m.right),  '#C05621');

    const pL = rect.left + b.left, pR = rect.right  - b.right;
    const pT = rect.top  + b.top,  pB = rect.bottom - b.bottom;
    if (p.top)    sideLabel(cx, pT + p.top/2,    ri(p.top),    '#276749');
    if (p.bottom) sideLabel(cx, pB - p.bottom/2, ri(p.bottom), '#276749');
    if (p.left)   sideLabel(pL + p.left/2,  cy,  ri(p.left),   '#276749');
    if (p.right)  sideLabel(pR - p.right/2, cy,  ri(p.right),  '#276749');

    const cw = ri(contentRect.width), ch = ri(contentRect.height);
    if (cw > 48 && ch > 16)
      sideLabel(contentRect.left + cw/2, contentRect.top + ch/2,
        `${cw} × ${ch}`, 'rgba(26,72,140,0.92)');

    buildTip(target, cs, rect, m, b, p, rootFz);
    inspectorTip.style.display = 'block';
  }

  function buildTip(target, cs, rect, m, b, p, rootFz) {
    const tag = target.tagName.toLowerCase();
    const cls = [...target.classList].slice(0,3).join('.');

    const anyM = m.top||m.right||m.bottom||m.left;
    const anyB = b.top||b.right||b.bottom||b.left;
    const anyP = p.top||p.right||p.bottom||p.left;

    const fontPx = ri(parseFloat(cs.fontSize));
    const rows = [
      ['element', cls ? `${tag}.${cls}` : tag,         '#94a3b8'],
      ['size',    `${ri(rect.width)} × ${ri(rect.height)} px`, '#63B3ED'],
      ...(anyM ? [['margin',  fmt4(m, rootFz), '#F6AD55']] : []),
      ...(anyB ? [['border',  shorthand(b)+'px', '#C05621']] : []),
      ...(anyP ? [['padding', fmt4(p, rootFz), '#68D391']] : []),
      ['—', '', ''],
      ['font',   cs.fontFamily.split(',')[0].replace(/["']/g,'').trim(), '#f0abfc'],
      ['size ',  `${fontPx}px / ${toRem(fontPx, rootFz)}`, '#f0abfc'],
      ['weight', cs.fontWeight, '#f0abfc'],
      ['color',  cs.color, '#f0abfc'],
    ];

    inspectorTip.innerHTML = rows.map(([k, v, c]) =>
      k === '—'
        ? `<div style="border-top:1px solid rgba(255,255,255,0.08);margin:4px 0 2px;"></div>`
        : `<div style="display:flex;gap:10px;">
             <span style="color:#475569;min-width:58px;flex-shrink:0">${k}</span>
             <span style="color:${c}">${v}</span>
           </div>`
    ).join('');
  }

  function positionTip(mx, my) {
    const tw = inspectorTip.offsetWidth||220, th = inspectorTip.offsetHeight||180, mg = 18;
    // Keep tooltip away from cascade panel (right side)
    let left = mx + mg, top = my + mg;
    const panelLeft = window.innerWidth - 320;
    if (left + tw > panelLeft - 10) left = mx - tw - mg;
    if (left < 10) left = mx + mg;
    if (top + th > window.innerHeight - 8) top = my - th - mg;
    inspectorTip.style.left = Math.max(8, left) + 'px';
    inspectorTip.style.top  = Math.max(8, top)  + 'px';
  }

  // ─── Cascade panel ───────────────────────────────────────────────────────────

  function paintCascade(target) {
    // Update element label in panel header
    const tag = target.tagName.toLowerCase();
    const id  = target.id ? `#${target.id}` : '';
    const cls = [...target.classList].slice(0,3).map(c => `.${c}`).join('');
    const tagEl = document.getElementById('__sl_cascade_tag__');
    if (tagEl) tagEl.textContent = tag + id + cls;

    const hintEl = document.getElementById('__sl_cascade_hint__');
    if (hintEl) hintEl.style.display = 'none';

    renderRules(getMatchingRules(target));
  }

  function getMatchingRules(element) {
    const results = [];

    // Inline styles (highest priority)
    if (element.style?.cssText) {
      results.push({
        selector: 'inline style',
        spec: [1,0,0], specStr: '——',
        props: inlineProps(element.style),
        source: 'inline', isInline: true,
      });
    }

    for (const sheet of document.styleSheets) {
      let rules;
      try { rules = sheet.cssRules; } catch { continue; }
      if (!rules) continue;

      const src = sheet.href
        ? new URL(sheet.href).pathname.split('/').filter(Boolean).pop() || sheet.href
        : '<style>';

      for (const rule of rules) {
        if (rule.type !== CSSRule.STYLE_RULE) continue;
        for (const sel of rule.selectorText.split(',').map(s => s.trim())) {
          try {
            if (!element.matches(sel)) continue;
            const spec = calcSpec(sel);
            results.push({
              selector: sel, spec, specStr: spec.join(','),
              props: ruleProps(rule.style),
              source: src, isInline: false,
            });
          } catch (_) {}
        }
      }
    }

    return results.sort((a, b) => {
      if (a.isInline !== b.isInline) return a.isInline ? -1 : 1;
      return cmpSpec(b.spec, a.spec);
    });
  }

  function calcSpec(sel) {
    let s = sel.replace(/:not\(([^)]*)\)/g, '$1').replace(/::[\w-]+/g, ' ');
    const ids   = (s.match(/#[\w-]+/g) || []).length;
    const cls   = (s.match(/\.[\w-]+|\[[^\]]*\]|:[\w-]+(?:\([^)]*\))?/g) || []).length;
    const types = (s.match(/(?:^|[\s+~>,(])([a-zA-Z][\w-]*)/g) || [])
                   .filter(t => t.trim() !== '*').length;
    return [ids, cls, types];
  }

  function cmpSpec(a, b) {
    for (let i = 0; i < 3; i++) if (a[i] !== b[i]) return a[i] - b[i];
    return 0;
  }

  function inlineProps(style) {
    const p = {};
    for (let i = 0; i < style.length; i++) p[style[i]] = style.getPropertyValue(style[i]);
    return p;
  }

  function ruleProps(style) {
    const p = {};
    for (let i = 0; i < style.length; i++) {
      const prop = style[i];
      p[prop] = style.getPropertyValue(prop) + (style.getPropertyPriority(prop) ? ' !important' : '');
    }
    return p;
  }

  function renderRules(rules) {
    const list = document.getElementById('__sl_cascade_list__');
    if (!list) return;

    if (!rules.length) {
      list.innerHTML = `<div style="padding:14px;color:rgba(255,255,255,0.25);font-size:11px;">
        No matched rules found.<br>Element uses browser defaults only.</div>`;
      return;
    }

    const wonProps = new Set();
    list.innerHTML = '';

    rules.forEach((rule, i) => {
      const winner = i === 0;
      const block  = mk('div', { borderBottom:'1px solid rgba(255,255,255,0.06)', padding:'9px 14px' });

      // Rule header row
      const hdr = mk('div', { display:'flex', alignItems:'flex-start',
        justifyContent:'space-between', gap:'8px', marginBottom:'6px' });

      const selSpan = mk('span', {
        fontSize:'11px', fontWeight:'500', wordBreak:'break-all', flex:'1',
        color: winner ? '#86efac' : 'rgba(255,255,255,0.38)',
      });
      selSpan.textContent = rule.selector;

      const metaCol = mk('div', { display:'flex', flexDirection:'column',
        alignItems:'flex-end', gap:'3px', flexShrink:'0' });

      const specBadge = mk('span', {
        fontSize:'9px', padding:'1px 6px', borderRadius:'3px',
        fontFamily:'ui-monospace,monospace',
        background: winner ? 'rgba(134,239,172,0.15)' : 'rgba(255,255,255,0.06)',
        color: winner ? '#86efac' : 'rgba(255,255,255,0.28)',
      });
      specBadge.textContent = rule.isInline ? 'inline' : `(${rule.specStr})`;

      const srcBadge = mk('span', { fontSize:'9px', color:'rgba(255,255,255,0.22)' });
      srcBadge.textContent = rule.source;

      metaCol.append(specBadge, srcBadge);
      hdr.append(selSpan, metaCol);
      block.appendChild(hdr);

      // Properties
      const propList = mk('div', { display:'flex', flexDirection:'column', gap:'2px' });
      const entries = Object.entries(rule.props);

      if (!entries.length) {
        const empty = mk('span', { fontSize:'10px', color:'rgba(255,255,255,0.18)' });
        empty.textContent = '(empty rule)';
        propList.appendChild(empty);
      }

      entries.forEach(([prop, val]) => {
        const overridden  = wonProps.has(prop);
        const isImportant = val.includes('!important');
        const row = mk('div', { display:'flex', gap:'6px', alignItems:'baseline' });

        const pSpan = mk('span', {
          fontSize:'10px', flexShrink:'0',
          color: overridden ? 'rgba(255,255,255,0.18)' : '#7dd3fc',
          textDecoration: overridden ? 'line-through' : 'none',
        });
        pSpan.textContent = prop + ':';

        const vSpan = mk('span', {
          fontSize:'10px', wordBreak:'break-all',
          color: overridden ? 'rgba(255,255,255,0.16)'
               : isImportant ? '#fbbf24'
               : 'rgba(255,255,255,0.60)',
          textDecoration: overridden ? 'line-through' : 'none',
        });
        vSpan.textContent = val;

        row.append(pSpan, vSpan);
        propList.appendChild(row);

        if (!overridden) wonProps.add(prop);
      });

      block.appendChild(propList);
      list.appendChild(block);
    });
  }

  // ─── Drawing helpers ─────────────────────────────────────────────────────────

  function drawRect(r, fill, border) {
    const d = ibox();
    css(d, { top:r.top+'px', left:r.left+'px',
      width:Math.max(0,r.width)+'px', height:Math.max(0,r.height)+'px',
      background:fill, border, boxSizing:'border-box' });
    inspectorEl.appendChild(d);
  }

  function sideLabel(cx, cy, text, bg) {
    const d = ibox();
    d.textContent = text;
    css(d, { top:cy+'px', left:cx+'px', transform:'translate(-50%,-50%)',
      background:bg, color:'white', fontSize:'9px', fontWeight:'700',
      padding:'1px 5px', borderRadius:'3px', whiteSpace:'nowrap',
      fontFamily:'ui-monospace,monospace', lineHeight:'1.6' });
    inspectorEl.appendChild(d);
  }

  function ibox() {
    const d = document.createElement('div');
    d.setAttribute('data-ibox', '');
    css(d, { position:'fixed', pointerEvents:'none' });
    return d;
  }

  // ─── Guide lines ─────────────────────────────────────────────────────────────

  function addGuide(type) {
    const pos = type === 'h' ? ri(window.innerHeight/2) : ri(window.innerWidth/2);
    const guide = { id: nextId++, type, pos };
    guides.push(guide);
    save();
    renderGuide(guide);
  }

  function renderAll() {
    if (!overlayEl) return;
    overlayEl.innerHTML = '';
    guides.forEach(renderGuide);
  }

  function renderGuide(guide) {
    const isH  = guide.type === 'h';
    const color = isH ? BLUE : AMBER;

    const lineEl = document.createElement('div');
    lineEl.setAttribute('data-guide-id', guide.id);
    css(lineEl, {
      position:'absolute',
      ...(isH
        ? { top:guide.pos+'px', left:'0', right:'0', height:'0', borderTop:`1.5px dashed ${color}` }
        : { left:guide.pos+'px', top:'0', bottom:'0', width:'0', borderLeft:`1.5px dashed ${color}` }),
      pointerEvents:'auto', cursor: isH ? 'ns-resize' : 'ew-resize',
    });

    // Wide hit area
    const hit = mk('div', {
      position:'absolute',
      ...(isH ? { top:'-7px', left:'0', right:'0', height:'15px' }
              : { left:'-7px', top:'0', bottom:'0', width:'15px' }),
      cursor: isH ? 'ns-resize' : 'ew-resize',
    });
    lineEl.appendChild(hit);

    const lbl = mk('div', {
      position:'absolute',
      ...(isH ? { top:'-21px', left:'10px' } : { left:'6px', top:'10px' }),
      background:color, color:'white', fontSize:'10px', fontWeight:'600',
      padding:'2px 7px', borderRadius:'5px', whiteSpace:'nowrap',
      lineHeight:'1.6', pointerEvents:'none',
      fontFamily:'-apple-system,BlinkMacSystemFont,"Segoe UI",monospace',
    }, isH ? `y: ${guide.pos}px` : `x: ${guide.pos}px`);
    lineEl.appendChild(lbl);

    const del = mk('div', {
      position:'absolute',
      ...(isH ? { top:'-21px', right:'10px' } : { left:'6px', top:'32px' }),
      width:'16px', height:'16px', background:color, color:'white',
      fontSize:'11px', fontWeight:'700', borderRadius:'50%',
      display:'flex', alignItems:'center', justifyContent:'center',
      cursor:'pointer', lineHeight:'1', pointerEvents:'auto',
    }, '×');
    del.addEventListener('click', e => {
      e.stopPropagation();
      guides = guides.filter(g => g.id !== guide.id);
      lineEl.remove();
      save();
    });
    lineEl.appendChild(del);

    makeGuideDraggable(lineEl, guide, lbl);
    overlayEl.appendChild(lineEl);
  }

  // ─── Dragging ────────────────────────────────────────────────────────────────

  function makeGuideDraggable(lineEl, guide, lbl) {
    const isH = guide.type === 'h';
    let active = false, startMouse, startPos;

    lineEl.addEventListener('mousedown', e => {
      if (e.target.textContent === '×') return;
      active = true;
      startMouse = isH ? e.clientY : e.clientX;
      startPos   = guide.pos;
      document.body.style.userSelect = 'none';
      document.body.style.cursor = isH ? 'ns-resize' : 'ew-resize';
      e.preventDefault();
    });

    window.addEventListener('mousemove', e => {
      if (!active) return;
      const newPos = Math.max(0, ri(startPos + (isH ? e.clientY - startMouse : e.clientX - startMouse)));
      guide.pos = newPos;
      if (isH) lineEl.style.top = newPos+'px'; else lineEl.style.left = newPos+'px';
      lbl.textContent = isH ? `y: ${newPos}px` : `x: ${newPos}px`;
    });

    window.addEventListener('mouseup', () => {
      if (!active) return;
      active = false;
      document.body.style.userSelect = '';
      document.body.style.cursor = inspectorActive ? 'crosshair' : '';
      save();
    });
  }

  function makeTrayDraggable(handle) {
    let active = false, ox, oy;
    handle.addEventListener('mousedown', e => {
      active = true;
      const r = trayEl.getBoundingClientRect();
      ox = e.clientX - r.left; oy = e.clientY - r.top;
      trayEl.style.transform = 'none';
      trayEl.style.left = r.left+'px'; trayEl.style.top = r.top+'px';
      trayEl.style.bottom = 'auto'; handle.style.cursor = 'grabbing';
      e.preventDefault();
    });
    window.addEventListener('mousemove', e => {
      if (active) { trayEl.style.left = (e.clientX-ox)+'px'; trayEl.style.top = (e.clientY-oy)+'px'; }
    });
    window.addEventListener('mouseup', () => { if (active) { active = false; handle.style.cursor = 'grab'; } });
  }

  // ─── Visibility / clear ──────────────────────────────────────────────────────

  function toggleVisibility() {
    guidesVisible = !guidesVisible;
    overlayEl.style.display = guidesVisible ? '' : 'none';
    const b = trayEl.querySelector('[data-eye]');
    if (b) b.textContent = guidesVisible ? '👁' : '🚫';
  }

  function clearAll() { guides = []; overlayEl.innerHTML = ''; save(); }

  // ─── Storage & messaging ─────────────────────────────────────────────────────

  function save() { chrome.storage.local.set({ [STORAGE_KEY]: guides }); }

  chrome.runtime.onMessage.addListener((msg) => {
    // ── Tray state (all tabs sync) ──────────────────────────────────────────
    if (msg.type === 'TRAY_STATE') {
      trayVisible = msg.open;
      trayEl.style.display = msg.open ? 'flex' : 'none';
      if (!msg.open && inspectorActive) {
        inspectorActive = false;
        document.body.style.cursor = '';
        cascadePanel.style.display = 'none';
        clearBoxes();
        css(btnInspect, { background:MINT+'18', border:`1px solid ${MINT}40`, color:MINT+'bb' });
        btnInspect.textContent = '◈ Inspect';
      }
    }

    // ── Guide sync (all tabs) ───────────────────────────────────────────────
    if (msg.type === 'GUIDES_UPDATED') { guides = msg.guides || []; renderAll(); }
  });

  // ─── Math helpers ────────────────────────────────────────────────────────────

  function sides(cs, prop, suffix='') {
    return {
      top:    parseFloat(cs[prop+'Top'   +suffix]) || 0,
      right:  parseFloat(cs[prop+'Right' +suffix]) || 0,
      bottom: parseFloat(cs[prop+'Bottom'+suffix]) || 0,
      left:   parseFloat(cs[prop+'Left'  +suffix]) || 0,
    };
  }

  function expand(rect, t, r, b, l) {
    return { top:rect.top-t, left:rect.left-l, width:rect.width+l+r, height:rect.height+t+b };
  }

  function shrink(rect, t, r, b, l) {
    return { top:rect.top+t, left:rect.left+l,
      width:Math.max(0,rect.width-l-r), height:Math.max(0,rect.height-t-b) };
  }

  function shorthand({ top:t, right:r, bottom:b, left:l }) {
    if (t===r && r===b && b===l) return `${ri(t)}`;
    if (t===b && r===l)          return `${ri(t)} ${ri(r)}`;
    return `${ri(t)} ${ri(r)} ${ri(b)} ${ri(l)}`;
  }

  function toRem(px, rootFz) {
    const v = px/rootFz;
    return (Number.isInteger(v) ? v : +v.toFixed(3)) + 'rem';
  }

  function fmt4(s, rootFz) {
    const sh = shorthand(s), max = Math.max(s.top,s.right,s.bottom,s.left);
    return max > 0 ? `${sh}px  (${toRem(max, rootFz)})` : '0';
  }

  function ri(n) { return Math.round(n); }

  // ─── DOM helpers ─────────────────────────────────────────────────────────────

  function css(node, styles) { Object.assign(node.style, styles); }

  function div(styles, slAttr) {
    const d = document.createElement('div');
    if (styles) css(d, styles);
    if (slAttr) d.setAttribute('data-sightline', slAttr);
    return d;
  }

  function mk(tag, styles, text) {
    const n = document.createElement(tag);
    if (styles) css(n, styles);
    if (text !== undefined) n.textContent = text;
    return n;
  }

  function mkBtn(label, accent, onClick) {
    const btn = document.createElement('button');
    btn.textContent = label;
    const bg = accent ? accent+'18' : 'rgba(255,255,255,0.07)';
    const bo = accent ? accent+'40' : 'rgba(255,255,255,0.13)';
    const co = accent || 'rgba(255,255,255,0.72)';
    css(btn, {
      background:bg, border:`1px solid ${bo}`, color:co,
      borderRadius:'8px', padding:'5px 11px', fontSize:'12px', fontWeight:'500',
      cursor:'pointer', fontFamily:'inherit', lineHeight:'1.3',
      transition:'background 0.12s', whiteSpace:'nowrap',
    });
    btn.addEventListener('mouseenter', () => { btn.style.background = accent ? accent+'2e' : 'rgba(255,255,255,0.12)'; });
    btn.addEventListener('mouseleave', () => {
      if (btn === btnInspect && inspectorActive) return;
      btn.style.background = bg;
    });
    btn.addEventListener('click', onClick);
    return btn;
  }

  function mkSep() {
    return mk('div', { width:'1px', height:'18px',
      background:'rgba(255,255,255,0.10)', margin:'0 1px', flexShrink:'0' });
  }

})();
