// Sightline — background service worker

const STORAGE_KEY = 'sightline_guides';
const TRAY_KEY    = 'sightline_tray_open';

// Icon click: toggle tray state in storage (broadcasts to ALL tabs via onChanged)
chrome.action.onClicked.addListener(async () => {
  const data  = await chrome.storage.local.get(TRAY_KEY);
  const isOpen = data[TRAY_KEY] || false;
  chrome.storage.local.set({ [TRAY_KEY]: !isOpen });
});

// Broadcast any storage change to every open tab
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;

  if (changes[STORAGE_KEY]) {
    const guides = changes[STORAGE_KEY].newValue || [];
    broadcast({ type: 'GUIDES_UPDATED', guides });
  }

  if (changes[TRAY_KEY]) {
    const open = changes[TRAY_KEY].newValue || false;
    broadcast({ type: 'TRAY_STATE', open });
  }
});

function broadcast(msg) {
  chrome.tabs.query({}, (tabs) =>
    tabs.forEach(tab =>
      chrome.tabs.sendMessage(tab.id, msg).catch(() => {})
    )
  );
}
